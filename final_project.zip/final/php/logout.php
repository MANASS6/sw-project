<?php
	session_start();
    session_destroy();
    header("Location: ../before login/index2.php");	



?>