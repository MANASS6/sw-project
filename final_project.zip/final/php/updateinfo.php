<?php
 	session_start();
    include ('dbh.php');

	if(isset($_POST['submit'])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$pass = $_POST['pass'];
		$tele = $_POST['tele'];
        $age = $_POST['age'];
        $adress = $_POST['adress'];
        $gender = $_POST['gender'];
        
		
	   $v = $_SESSION['patient']['patient_id'];
       
	   /*echo $v."<br>";
	   echo $name."<br>";
	   echo $pass."<br>";
	   echo $email."<br>";
	   echo $tele."<br>";
	   echo $age."<br>";
	   echo $adress."<br>";
	   echo $gender;*/
	   
	   $sql =  "UPDATE patient SET p_name = '$name' ,
	   password = '$pass', e_mail = '$email', phone = '$tele' ,age = '$age' ,adress = '$adress' ,
	   gender = '$gender' WHERE patient_id= '$v'";
	   //update database
	   mysqli_query($conn,$sql);
	   
	   $sql = "SELECT * FROM patient WHERE p_name ='$name' AND password = '$pass'";
       $result = mysqli_query($conn,$sql);
		

		 if(! $row=mysqli_fetch_assoc($result))	
		 {
			echo"error could not read database";
		 }
		 else
		 {
           $_SESSION['patient'] =$row ;	
          header("Location: ../Login/patient/Profile.php");
		  
		 }
     }



?>