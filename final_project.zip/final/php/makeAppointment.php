<?php
 	session_start();
    include ('dbh.php');

	if(isset($_POST['submit'])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$tele = $_POST['tele'];
        $days= $_POST['days'];
        $hours = $_POST['hours'];
       
       
        $sql0 = "INSERT INTO `appointment`( `p_name`, `email`, `phone`)
        VALUES ('$name','$email','$tele')";
		
        mysqli_query($conn,$sql0);
		
		//get patient id inserted
		$sql1 = "SELECT appointment_id FROM appointment  WHERE p_name ='$name' AND email = '$email'
        AND phone ='$tele'";
		
                
        $result =mysqli_query($conn,$sql1);
		$row=mysqli_fetch_assoc($result);
        $app_id = $row['appointment_id'];
		
        
		 $sql2 = "INSERT INTO  `doc_schedule` (`day`,`time`, `app_id`)
         VALUES ('$days','$hours','$app_id')";
		 
		 //update database
		 mysqli_query($conn,$sql2);
	if(isset($_SESSION['patient']))
     {
        if($_SESSION['patient']['patient_id'] == 0){
        
          header("Location: ../Login/admin/Thanks for adding.php");
        
        }
        else 
        {

            //if loged in inseret p_id;
            $v = $_SESSION['patient']['patient_id'];
            $sql0 = "UPDATE `appointment` SET `patient_id` = '$v' WHERE `p_name` = '$name' AND
			`email` = '$email' AND '$tele' = '$tele'";
		
		    mysqli_query($conn,$sql0);
            header("Location: ../Login/patient/aftercontactus2.php");

        }
        
     }
     else
     {
        	    header("Location: ../before login/afterContactus.php");

     }
	  	
     }


?>