<?php
 	session_start();
    include ('dbh.php');

	if(isset($_POST['submit'])) {
        $p_id = $_POST['p_id'];
		$pb = $_POST['pb'];
		$hgb = $_POST['hgb'];
		$bg = $_POST['bg'];
		$rr = $_POST['rr'];
        $xr = $_POST['xr'];
        $dseases = $_POST['dseases'];
        $notes = $_POST['notes'];
        $proc= $_POST['proc'];
        $price= $_POST['price'];
        $date= $_POST['date'];
        $time= $_POST['time'];

	  /* echo $p_id."<br>";
	   echo $pb."<br>";
	   echo $hgb."<br>";
	   echo $bg."<br>";
	   echo $rr."<br>";
	   echo $xr."<br>";
	   echo $proc."<br>";
	   echo $notes; */
       
	   $sql0 =  "UPDATE `medical_history` SET `pb`= '$pb' ,`hgp`= '$hgb' ,
       `Blood_Glucose`= '$bg',`Radiation_result`='$rr' WHERE `patient_id` = '$p_id'";
       
       //update dataBase with basic info                
	   mysqli_query($conn,$sql0);
     
       $sql1 = "SELECT medical_history_id FROM medical_history WHERE patient_id = '$p_id'";
       
       //update database
       $result =mysqli_query($conn,$sql1);
       //get MH_id
       $row=mysqli_fetch_assoc($result);
       $m_id = $row['medical_history_id'];
       
       
       $sql2 = "INSERT INTO x_rays (x_ray,MH_id) VALUES ('$xr','$m_id')";
       //update xray
       mysqli_query($conn,$sql2);
       
       $sql3 = "INSERT INTO diseases (diseases,MH_id) VALUES ('$dseases','$m_id')";
       //update diseases
       mysqli_query($conn,$sql3);
       
       $sql4 = "INSERT INTO notes (notes,MH_id) VALUES ('$notes','$m_id')";
       //update diseases
       mysqli_query($conn,$sql4);
     
       $sql5 = "INSERT INTO procuder (procuder_name,price,date,time,patient_id)
       VALUES ('$proc','$price','$date','$time','$p_id')";
     
       //update diseases
       mysqli_query($conn,$sql5);
       
       //redirecting
       header("Location: ../Login/admin/Updatesuccess.php");

  }


?>