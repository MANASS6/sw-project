<?php 
	
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "clinc";
	//connect to database
	$conn = mysqli_connect($server, $username, $password, $database);
	
	if(!$conn) {
		die("Connection Failed ".mysqli_error());
	}

 ?>