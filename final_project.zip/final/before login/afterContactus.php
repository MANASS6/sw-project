<!DOCTYPE HTML>
<html>

<head>
  <title>simplestyle_blue_trees - a page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>

<body>
   
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index2.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>
          <h2>Improve your dental health</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li ><a href="index2.php">Home</a></li>

                    <li ><a href="Appointment2.php">Appointment</a></li>

                   

                    <li class="selected"><a href="Contactus.php">Contact Us</a></li>
                    <li><a href="about%20us.php">about Us</a></li>
        </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
   
         <div id="sidebar_container">
      <div class="imgbox">
				<img src="style/0011.jpg" width="200" height="500">
				<br />
				
		  </div>
      
     

       </div>
        
     
      <div id="content">
       
        <h1> Thank you for contacting us </h1>
             
        
      </div>

    </div>
   
      
  <div id="footer">
     <p><a href="index2.php">Home</a> | <a href="Appointment2.php">Appointment</a> |  <a  href="Contactus.php">Contact Us</a> |  <a  href="about%20us.php">about us</a> </p>
    </div> 
    
      
  </div>
</body>
</html>
