<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
    <title>simplestyle_blue_trees</title>
    <meta name="description" content="website description">
    <meta name="keywords" content="website keywords, website keywords">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link rel="stylesheet" type="text/css" href="style/style.css">
</head>

<body>
    <div id="main">
        <div id="header">
            <div id="logo">
                <div id="logo_text">
                    <!-- class="logo_colour", allows you to change the colour of the text -->

                    <h1><a href="index2.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>

                    <h2>Improve your dental health</h2>
                </div>
            </div>

            <div id="menubar">
                <ul id="menu">
                    <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->

                    <li class="selected"><a href="index2.php">Home</a></li>

                    <li><a href="Appointment2.php">Appointment</a></li>

                   

                    <li><a href="Contactus.php">Contact Us</a></li>
                    <li><a href="about%20us.php">about Us</a></li>
                </ul>
            </div>
        </div>

        <div id="content_header"></div>

        <div id="site_content">
            <div id="banner"></div>

            <div id="sidebar_container">
                <form action="../php/login.php" method="POST">
                    <div class="imgcontainer"><img src="style/img_avatar2.png" alt="Avatar" class="avatar"></div>

                    <div class="container">
                        <label><b>Username</b></label>
                        <input type="text" placeholder="Enter Username" name="name" required="">
                        <label><b>Password</b></label>
                        <input type="password" placeholder="Enter Password" name="pass" required="">
                        <button type="submit" name="login">Login</button> 
                    </div>

                    <div class="container" style="background-color:#f1f1f1">
                    </div>
                </form>
            </div>

            <div id="content">
                <!-- insert the page content here -->

                <h1 style="font-family:verdana; color:#00C6F0;" align="center">MAKE THE FULL OUT OF UR SMILE</h1>

                <p>"What a shame then that it also finds that many people are deterred from smiling because of shyness or the fear of it being misconstrued. everything worthwhile in life carries an element of risk and only a very sour person could find anything offensive in a smile. So let us all dare to beam a bit more and even more importantly always to greet a smile with one in return."</p>

                <p>You can prevent most problems with teeth and gums by taking these steps</p>

                <p>Brush your teeth 2 times a day with fluoride "FLOOR-ide" toothpaste.</p>

                <p>Floss between your teeth every day.</p>

                <p>Visit a dentist regularly for a checkup and cleaning.</p>

                <p>Cut down on sugary foods and drinks.</p>
            </div>
        </div>

        <div id="content_footer"></div>

        <div id="footer">
            <p><a href="index2.php">Home</a> | <a href="Appointment2.php">Appointment</a> |  <a  href="Contactus.php">Contact Us</a> |  <a  href="about%20us.php">about us</a> </p>
        </div>
    </div>
</body>
</html>

            