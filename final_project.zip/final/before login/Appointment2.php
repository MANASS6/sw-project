<!DOCTYPE HTML>
<html>

<head>
  <title>simplestyle_blue_trees - a page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>

<body>
   
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index2.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>
          <h2>Improve your dental health</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
           <li><a href="index2.php">Home</a></li>

                    <li  class="selected"><a href="Appointment2.php">Appointment</a></li>

                   

                    <li><a href="Contactus.php">Contact Us</a></li>
                    <li><a href="about%20us.php">about Us</a></li>
        </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
   
         <div id="sidebar_container">
      <div class="imgbox">
				<img src="style/0011.jpg" width="200" height="500">
				<br />
				
		  </div>
      
     

       </div>
        
     
      <div id="content">
       
        <h1>Make an Appointment</h1>
             <div class="form_settings">
			<form action = "../php/makeAppointment.php" method= "POST" >
            <p><span>Name</span><input class="contact" type="text" name="name" value="" /></p>
            <p><span>Email Address</span><input class="contact" type="text" name="email" value="" /></p>
            <p><span>Telephone number</span><input class="contact" type="text" name="tele" value="" /></p>
            <p><span>days</span> <select name="days">
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                     <option value="Sunday">Sunday</option>  </select> </p>
                
                                                                    
               
                <p><span>hours</span> <select name="hours">
                    <option value="AM">9am - 3pm </option>
                    <option value="PM">6pm - 12am </option>  </select> </p>
                    
                                                                  
          
            <p style="padding-top: 15px"><span>&nbsp;</span>
			<input class="submit" type="submit" name="submit" value="submit" /> </p>
         </form>
		  </div>       
        
      </div>

    </div>
   
      
  <div id="footer">
      <p><a href="index2.php">Home</a> | <a href="Appointment2.php">Appointment</a> |  <a  href="Contactus.php">Contact Us</a> |  <a  href="about%20us.php">about us</a> </p>
    </div> 
    
      
  </div>
</body>
</html>
