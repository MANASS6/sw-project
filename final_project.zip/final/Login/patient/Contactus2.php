<?php
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
    <title>simplestyle_blue_trees</title>
    <meta name="description" content="website description">
    <meta name="keywords" content="website keywords, website keywords">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link rel="stylesheet" type="text/css" href="style/style.css">
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>
          <h2>Improve your dental health</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="index.php">Home</a></li>

                    <li><a href="Appointment.php">Appointment</a></li>

                     <li><a href="Profile.php">profile</a></li>


                    <li  class="selected"><a href="Contactus2.php">Contact Us</a></li>
                      <li><a href="aboutus2.php">about Us</a></li>
                    
        </ul>
      </div>
    </div>
  <div id="content_header"></div>
    <div id="site_content">
      <div id="sidebar_container">
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <!-- insert your sidebar items here -->
            <h3>Our Address</h3>
              <p> moheb Street,Tanta,Egypt <br /> </p>
            <h4>MANNASS@dentalsite.com </h4>
            <h5> Tel: 123-456-7890</h5>
            <h6> Fax: (+200)123-456-7890</h6>
              
            
          </div>
          <div class="sidebar_base"></div>
        </div>
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
              <h3>Opening days</h3>
              <ul>
            <li> sunday </li>
              <li> monday </li>
               <li> Tuesday </li>
              <li> Wednesday </li>
               <li> Thursday </li>
              <li> Friday </li>
              </ul>
              
            <h3>Opening Hours</h3>
            <ul>
              <li> 9Am-3PM </li>
              <li> 6PM-12AM </li>
              
            </ul>
              
          </div>
          <div class="sidebar_base"></div>
        </div>
           <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Soical</h3>
            <div class="imgbox">
                
			<a href="https://www.facebook.com"	> <img src="style/social-media-icons-01.png" width="50" height="50" ></a>
                <a href="https://www.twitter.com"	>   <img src="style/social-media-icons-50x50-twitter-blue.png" width="40" height="40"> </a>
				
				
		  </div>
          </div>
          <div class="sidebar_base"></div>
        </div>
       
        </div>
     
   
      <div id="content">
        <!-- insert the page content here -->
        <h1>Contact Us</h1>
         
          <div class="form_settings">
            <p><span>Name</span><input class="contact" type="text" name="your_name" value="" /></p>
            <p><span>Email Address</span><input class="contact" type="text" name="your_email" value="" /></p>
            <p><span>Message</span><textarea class="contact textarea" rows="8" cols="50" name="your_enquiry"></textarea></p>
            <p style="padding-top: 15px"><span>&nbsp;</span><a href="aftercontactus2.php"> <input class="submit" type="submit" name="contact_submitted" value="submit" /> </a> </p>
          </div>       
        
      </div>
    </div>
    <div id="content_footer"></div>
    <div id="footer">
      <p><a href="index.php">Home</a> | <a href="Appointment.php">Appointment</a> | <a href="Profile.php">Profile</a>|  <a  href="Contactus2.php">Contact Us </a> | <a href="aboutus2.php">about us</a> </p>
    </div>
  </div>
</body>
</html>