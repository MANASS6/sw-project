<?php
	session_start();
	$var = array();
	if(isset($_SESSION['patient']))
	$var = $_SESSION['patient'];
?>
<!DOCTYPE HTML>
<html>

<head>
  <title>simplestyle_blue_trees - another page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>
          <h2>Improve your dental health</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
           <li ><a href="index.php">Home</a></li>

                    <li><a href="Appointment.php">Appointment</a></li>

                     <li class="selected"><a href="Profile.php">profile</a></li>


                    <li><a href="Contactus2.php">Contact Us</a></li>
                      <li><a href="aboutus2.php">about Us</a></li>
        </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
      <div id="sidebar_container">
        <div class="sidebar">
         
             <h1> Welcome! </h1>
            <form action="/action_page.php">
               
                    <div class="imgcontainer"><img src="style/img_avatar2.png" alt="Avatar" class="avatar"></div>
                          <button type="submit">Update Your Photo</button>
            <!--        <div class="container">
                        <label><b>Username</b></label> <input type="text" placeholder="Enter Username" name="uname" required=""> <label><b>Password</b></label> <input type="password" placeholder="Enter Password" name="psw" required=""> <button type="submit">Login</button> <input type="checkbox" checked="checked"> Remember me
                    </div> -->
               

                  <!--  <div class="container" style="background-color:#f1f1f1">
                    </div> -->
                </form>
         
       <!--  <div class="sidebar_base"></div> -->
        </div>
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Basic Information</h3>
              
            <ul>
              <li> Name   :  <?php  echo $var['p_name'];?> </li>
              <li>Age     :  <?php  echo $var['age'];?> </li>
              <li>Email   :  <?php  echo $var['e_mail'];?> </li>
              <li>Address :  <?php  echo $var['adress'];?> </li>
              <li>gender  :  <?php  echo $var['gender'];?> </li>
              <li>phone   :  <?php  echo $var['phone'];?> </li> 
                
            </ul>
              <button type="submit">  <a href="Edityourinformation.php"> Edit Information </a> </button> 
            </div>
          <div class="sidebar_base"></div>
        </div>
     <!--   <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Search</h3>
            <form method="post" action="#" id="search_form">
              <p>
                <input class="search" type="text" name="search_field" value="Enter keywords....." />
                <input name="search" type="image" style="border: 0; margin: 0 0 -9px 5px;" src="style/search.png" alt="Search" title="Search" />
              </p>
            </form>
          </div>
          <div class="sidebar_base"></div>
        </div> -->
      </div>
      <div id="content">
        <!-- insert the page content here -->
        <h1>Your Medical History</h1>
           <p><span> </span><textarea class="contact textarea" rows="25" cols="80" name="your_enquiry"></textarea></p>
       <h1>receipt</h1>
          <p><span> </span><textarea class="contact textarea" rows="5" cols="30" name="your_enquiry"></textarea></p>
      </div>
       
    </div>
    <div id="content_footer"></div>
    <div id="footer">
      <p><a href="index.php">Home</a> | <a href="Appointment.php">Appointment</a> | <a href="Profile.php">Profile</a>|  <a  href="Contactus2.php">Contact Us </a> | <a href="aboutus2.php">about us</a> </p>
    </div> 
    
  </div>
</body>
</html>
