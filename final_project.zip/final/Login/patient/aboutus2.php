<?php
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
    <title>simplestyle_blue_trees</title>
    <meta name="description" content="website description">
    <meta name="keywords" content="website keywords, website keywords">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link rel="stylesheet" type="text/css" href="style/style.css">
</head>

<body>
    <div id="main">
        <div id="header">
            <div id="logo">
                <div id="logo_text">
                    <!-- class="logo_colour", allows you to change the colour of the text -->

                    <h1><a href="index.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>

                    <h2>Improve your dental health</h2>
                </div>
            </div>

            <div id="menubar">
                <ul id="menu">
                    <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->

                     <li ><a href="index.php">Home</a></li>

                    <li><a href="Appointment.php">Appointment</a></li>

                     <li><a href="Profile.php">profile</a></li>


                    <li><a href="Contactus2.php">Contact Us</a></li>
                      <li class="selected"><a href="aboutus2.php">about Us</a></li>
                    
                </ul>
            </div>
        </div>

        <div id="content_header"></div>

        <div id="site_content">
            <div id="banner"></div>

            <div id="sidebar_container">
                <form action="/action_page.php">
                    <div class="imgcontainer"><img src="style/1800288_710496019038179_1147356602820083085_n.jpg" alt="Avatar" class="avatar"></div>

                    <div class="container">
                       <h1>Our Servies</h1>
                        <ul>
                        <li> Teeth Whitening </li>
                        <li> Dental Hygiene     </li> 
                            <li> Dental Filling </li>
                        
                        <li> Routine Exams </li>
                        <li> Emergency Dentistry </li>
                        
                        </ul>
                    </div>

                </form>
            </div>

            <div id="content">
                <!-- insert the page content here -->

                <h1 style="font-family:verdana; color:#00C6F0;" align="center">MAKE THE FULL OUT OF UR SMILE</h1>

                <p>MAANSS Dental Clinic is one of largest and most modern private centres for general dentistry and implantology. Located in the Tanta city, we’re just a 1-hour drive from cairo.</p>

                <p>We’re a talented team of leading dentistry professionals that provide our local and international patients with the highest standards of care, by offering a wide-range of treatment options. Our services focus on high end implantology (including immediate loading procedures), aesthetic and cosmetic dentistry, dental crowns, dental veneers, CEREC, teeth whitening, root canal treatment, gum treatment, hygienist services and wisdom tooth removal.</p>

                <h1> Our Doctors </h1>
                 <div class="imgbox">
                
			   
                <img src="style/Capture.PNG" width="226" height="240"> 
				<img src="style/10632646_929368283785765_3930562930705303620_n.jpg" width="226" height="240">
                     
				
		  </div>
            </div>
        </div>

        <div id="content_footer"></div>

        <div id="footer">
              <p><a href="index.php">Home</a> | <a href="Appointment.php">Appointment</a> | <a href="Profile.php">Profile</a>|  <a  href="Contactus2.php">Contact Us </a> | <a href="aboutus2.php">about us</a> </p>
        </div>
    </div>
</body>
</html>