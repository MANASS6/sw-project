<?php
	session_start();
	?>

<!DOCTYPE HTML>
<html>

<head>
  <title>simplestyle_blue_trees - a page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>

<body>
   
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index3.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>
          <h2>Improve your dental health</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li ><a href="index3.php">Home</a></li>
         
          <li class="selected"><a href="admin.php">Admin</a></li>
        
        </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
   
         <div id="sidebar_container">
      <div class="imgbox">
				<img src="style/0011.jpg" width="200" height="500">
				<br />
				
		  </div>
      
     

       </div>
        
     
      <div id="content">
       
        <h1> Archive of patient </h1>
             
         <p>Name :</p>
          <p> Age :</p>
          <p> phone : </p>
          <p> email : </p>
           <p> gender : </p>
           <p> address : </p>
     <h1> Medical History</h1>
           <p><span> </span><textarea class="contact textarea" rows="25" cols="80" name="your_enquiry"></textarea></p>
        
      </div>

    </div>
   
      
  <div id="footer">
      <p><a href="index3.php">Home</a> | <a href="admin.php">Admin</a> </p>
    </div> 
    
      
  </div>
</body>
</html>
