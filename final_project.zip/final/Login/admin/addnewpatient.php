<?php
	session_start();
	?>

<!DOCTYPE HTML>

<html>

<head>
  <title>simplestyle_blue_trees - a page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>

<body>
   
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index3.php">MAANSS<span class="logo_colour">Dentist Clinic</span></a></h1>
          <h2>Improve your dental health</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li ><a href="index3.php">Home</a></li>
         
          <li class="selected"><a href="admin.php">Admin</a></li>
        
        </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
   
         <div id="sidebar_container">
      <div class="imgbox">
				<img src="style/0011.jpg" width="200" height="500">
				<br />
				
		  </div>
      
     

       </div>
        
     
      <div id="content">
       
        <h1>Add New patient</h1>
             <form class="form_settings" action = "../../php/addpatient.php" method="POST">
							
			       <div class="form_settings">
            <p><span>Name</span><input class="contact" type="text" name="name" value="" /></p>
            <p><span>Email </span><input class="contact" type="text" name="email" value="" /></p>
					  <p><span>Password </span><input class="contact" type="text" name="pass" value="" /></p>
            <p><span>Telephone number</span><input class="contact" type="text" name="tele" value="" /></p>
               <p><span>Age</span><input class="contact" type="text" name="age" value="" /></p>
               <p><span>Address</span><input class="contact" type="text" name="adress" value="" /></p>
               <p> Gender </p>
              <input type="radio" name="gender" value="male" checked>Male
							<input type="radio" name="gender" value="female">Female
							
              <h1> Medical Information </h1>
              <p><span>BP</span><input class="contact" type="text" name="pb" value="" /></p>
              <p><span>Hgb</span><input class="contact" type="text" name="hgb" value="" /></p>
              <p><span> Blood Glucose</span><input class="contact" type="text" name="bg" value="" /></p>
              <p><span> Radiation result</span><input class="contact" type="text" name="rr" value="" /></p>
              <p><span>x_rays Result</span><input class="contact" type="text" name="xr" value="" /></p>
			  <p><span>diseases</span><input class="contact" type="text" name="dseases" value="" /></p>
			  <p><span>notes</span><input class="contact" type="text" name="notes" value="" /></p>

         
                                                                  
          
              <p style="padding-top: 15px"><span>&nbsp;</span>
							<input class="submit" type="submit" name="submit" value="Registration" />
							</p>
          </div>
						 </form>
        
      </div>

    </div>
   
      
  <div id="footer">
      <p><a href="index3.php">Home</a> | <a href="admin.php">Admin</a> </p>
    </div> 
    
      
  </div>
</body>
</html>
